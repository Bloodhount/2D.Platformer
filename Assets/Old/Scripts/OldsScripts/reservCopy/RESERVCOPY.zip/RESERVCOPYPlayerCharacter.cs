﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCharacter : MonoBehaviour
{
    public Animator PlAnim;
    public Rigidbody2D PlRb;
    public Vector2 moveVector;
    [SerializeField] public float PlayerSpeed ;




    void Start()
    {
        PlRb = GetComponent<Rigidbody2D>();
        PlAnim = GetComponent<Animator>();

    }

    private void FixedUpdate()
    {
        WalkL();
        // WalkR();
        Jump();
        CheckingGround();

    }

    void Update()
    {
        //WalkL();
        //WalkR();
    }

    void WalkL()
    {
        moveVector.x = Input.GetAxis("Horizontal");
         PlRb.velocity = new Vector2(moveVector.x * PlayerSpeed, PlRb.velocity.y);
        // PlRb.AddForce(moveVector * PlayerSpeed);

        if (PlayerSpeed > 0)
        {
            PlAnim.SetFloat("PlMoveX", moveVector.x);

        }
        
    }

    //void WalkR()
    //{
    //    moveVector.x = Input.GetAxis("Horizontal");
    //    PlRb.velocity = new Vector2(moveVector.x * PlayerSpeed, PlRb.velocity.y);

    //    if (PlayerSpeed < 0)
    //    {
    //        PlAnim.SetFloat("PlMoveX", -moveVector.x);
    //    }
    //}

    public float _jumpForce = 7f;
    public bool _jumpControl;
    public float _jumpTime = 0;
    public float _jumpControlTime = 0.7f;
    private int _jumpCount = 0;
    public int _maxJumpValue = 2;
    public float _doubleJumpVelocity = 10f;

    void Jump()
    {
        if (Input.GetKey(KeyCode.Space))  
        {
            if (plOnGrnd)
            {
                PlAnim.StopPlayback();
                PlAnim.Play("Jump");
                _jumpControl = true;
                print("jump");
            }            
        }
        else
        {

            _jumpControl = false;
        }

        if (Input.GetKeyDown(KeyCode.Space) && !plOnGrnd && (++_jumpCount < _maxJumpValue))
        {
            PlAnim.StopPlayback();
            PlAnim.Play("doubleJump");
            PlRb.velocity = new Vector2(0, _doubleJumpVelocity);
            print("doubleJump");
        }

        if (plOnGrnd)
        {
            _jumpCount = 0;
        }

        if (_jumpControl)
        {
            if ((_jumpTime += Time.deltaTime) < _jumpControlTime)
            {

                PlRb.AddForce(Vector2.up * _jumpForce / (_jumpTime * 10));
            }
        }
        else
        {
            _jumpTime = 0;
        }



        //if (Input.GetKeyDown(KeyCode.Space) && plOnGrnd)
        //{
        //    print("checked!");

        //    PlRb.AddForce(Vector2.up * _jumpForce);
        //}
    }

    public bool plOnGrnd;
    public Transform CheckGrnd;
    public float checkRadius = 0.5f;
    public LayerMask Ground;

    void CheckingGround()
    {
        plOnGrnd = Physics2D.OverlapCircle(CheckGrnd.position, checkRadius, Ground);
        PlAnim.SetBool("plOnGrnd", plOnGrnd);

    }

}
